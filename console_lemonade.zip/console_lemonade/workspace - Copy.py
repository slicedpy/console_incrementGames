import time
import sys

for i in range(10):
    sys.stdout.write("\rCountdown: %d" % i)
    sys.stdout.flush()
    time.sleep(1)
print ''
