import time
import csv
import random

go_flag = 1

def create_banner(banner_file="banner.txt",whichMenu="start"):
    options_menu=["[S]tart Racing","[H]orse Catalog/Stats","[R]ace Records","[A]bout"]

    if whichMenu == "start":
        with open(banner_file,'rb') as banner:
            print banner.read()
            time.sleep(2)
            for each in options_menu:
                gap = (84-len(each))/2
                print " "*gap + each + " "*gap
                
    if whichMenu == "continue":
        print "SELECT AN OPTION:"
        print "=-" * 12
        for each in options_menu:
            print each
        print "\n"

    if whichMenu == "about":
        with open(banner_file,'rb') as banner:
            print banner.read()

    if whichMenu == "end":
        with open(banner_file,'rb') as banner:
            print banner.read()

create_banner()
while go_flag == 1:
    user_input = raw_input("\nMake a selection! ") or "A"

    if user_input.upper() == "A":
        create_banner("about_banner.txt","about")
