import time
import random

global water_units
global lemon_units
global sugar_units
global wallet
global recipe
global bizDay
global batch
global waterPrice
global lemonPrice
global sugarPrice
global marketFlag

# game stats
global statTotalSales
global statTotalCups

water_units = 4
lemon_units = 4
sugar_units = 8
wallet = 20.00
recipe = [3,2,1]
bizDay = 1
batch = 20
marketFlag = False
statTotalSales = 0
statTotalCups = 0

# Make Profit stat Net Gain/Net Loss)

def setMarket():
    global waterPrice
    global lemonPrice
    global sugarPrice

    waterPrice = float(random.randint(1,3))
    lemonPrice = float(random.randint(2,5))
    sugarPrice = float(random.randint(4,7))


def checkInventory():
    global water_units
    global lemon_units
    global sugar_units
    global wallet
    global bizDay
    global batch

    print "-"*45
    print "ON HAND LIST (DAY: " + str(bizDay) + ")"
    print "-"*45
    print "Water OH: " + str(water_units)
    print "Lemon OH: " + str(lemon_units)
    print "Sugar OH: " + str(sugar_units)
    print "Ready to Sell: " + str(batch)
    print "Wallet :$" + str(("%.2f" % wallet))
    
def makeLemonade():
    global water_units
    global lemon_units
    global sugar_units
    global recipe
    global batch

    print "\nLet's make Lemonade! 1 Batch = 20 cups"
    userBatch = int(raw_input("How many batches do you want to make?: ")) or 1
    waterNeeded = 3*userBatch
    lemonNeeded = 2*userBatch
    sugarNeeded = 1*userBatch

    if water_units >= waterNeeded and\
       lemon_units >= lemonNeeded and sugar_units >= sugarNeeded:

        water_units -= waterNeeded
        lemon_units -= lemonNeeded
        sugar_units -= sugarNeeded

        batch += (userBatch * 20)
    
    else:
        if water_units < waterNeeded:
            print "\nNot enough water" + " for " + str(userBatch) + " batches.\nNEED: " + str(waterNeeded) 
            print "HAVE: " + str(water_units)
            
        elif lemon_units < lemonNeeded:
            print "\nNot enough lemon" + " for " + str(userBatch) + " batches.\nNEED: " + str(lemonNeeded)
            print "HAVE: " + str(lemon_units)

        elif sugar_units < sugarNeeded:
            print "\nNot enough sugar" + " for " + str(userBatch) + " batches.\nNEED: " + str(userBatch)
            print "HAVE: " + str(sugar_units)

    print "\nYou have " + str(batch) + " ready to sell!\n"

    
def saleLemonade():
    global wallet
    global bizDay
    global batch
    global marketFlag

    global statTotalSales
    global statTotalCups

    whammyFlag = random.randint(0,5)
    
    start = 0
    sold_out_flag = 0


    sold_qty = 0
    sellPrice = float(raw_input("What price do you want to set?: $") or 1.00)
    
    if batch >0:
        print "~~" * 30
        print "LEMONADE! GET YOUR LEMONADE HERE!"
        print "~~" * 30
        #print "\n"

        buy_chance = 0
        
        while start <= 60:
            willingPrice = round(random.uniform(0.75,2.5),2)
            interestFlag = random.randint(0,1)
            
            if abs(sellPrice - willingPrice ) <= 0.45\
               and interestFlag == 1:
                buy_chance = 1

            time.sleep(1)

            if buy_chance == 1 and batch > 0:
                batch -= 1
                sold_qty +=1
            else:
                if batch == 0:
                    sold_out_flag += 1

            if sold_out_flag == 1:
                print "SOLD OUT @ " + str(start%12) +"Hrs"
                sold_out_flag += 1
                
            start += 1

        till = float(sold_qty * sellPrice)
        print "You made: $" + str(("%.2f" % till))
        wallet += till
        statTotalSales += till
        statTotalCups += sold_qty
        bizDay += 1

    else:
        print "\nYou don't have enough supplies to open"

    marketFlag = False
    
    if whammyFlag == 5:
        batch = 0
        print "OH NO! The batch went bad!\n"
        


def buySupplies():
    global water_units
    global lemon_units
    global sugar_units
    global waterPrice
    global lemonPrice
    global sugarPrice
    global wallet
    global marketFlag

    if marketFlag == False:
        setMarket()

    options = ["[W]ater ($"+str(waterPrice)+")","[L]emons ($"+str(lemonPrice)+")",\
               "s[U]gar ($"+str(sugarPrice)+")","\n[C]heck Wallet"]

    for op in options:
        print op

    grandTotal = 0.00

    inStore_flag = True
    while inStore_flag == True:
        purchaseTotal = 0.00
        
        userShelf = raw_input("\nWhat do you want to buy?: ").upper() or "X"

        if userShelf =="W":
            userQty = raw_input("Desire quanity: ") or 1.00

            purchaseTotal += (float(userQty)*waterPrice)
            grandTotal += purchaseTotal
            if wallet < purchaseTotal:
                print "\nYou don't have enough to buy "\
                      + str(int(userQty)) + " units of water."
            else:
                wallet -= purchaseTotal
                water_units += int(userQty)
                
                
        if userShelf =="L":
            userQty = raw_input("Desire quanity: ") or 1.00

            purchaseTotal += (float(userQty)*lemonPrice)
            grandTotal += purchaseTotal
            if wallet < purchaseTotal:
                print "\nYou don't have enough to buy "\
                      + str(int(userQty)) + " units of lemons."
            else:
                wallet -= purchaseTotal
                lemon_units += int(userQty)

        if userShelf =="U":
            userQty = raw_input("Desire quanity: ") or 1.00

            purchaseTotal += (float(userQty)*sugarPrice)
            grandTotal += purchaseTotal
            if wallet < purchaseTotal:
                print "\nYou don't have enough to buy "\
                      + str(int(userQty)) + " units of sugar."
                
            else:
                wallet -= purchaseTotal
                sugar_units += int(userQty)
                
        if userShelf =="C":
            print "You have $" + str(("%.2f" % wallet)) + "."

        if userShelf =="X":
            userConfirmation = raw_input("Are your sure?: ").upper() or "Y"
            if userConfirmation == "Y":
                inStore_flag = False
            else:
                inStore_flag = True
                
    
    print "\nThank you for shopping\nYou spent $" + ("%.2f" % grandTotal)
    print "Wallet :$" + str(("%.2f" % wallet))
    marketFlag = True


game_on = True
while game_on == True:
    options = ["[S]ale Lemonade","[B]uy Supplies",\
               "[M]ake Lemondade","[R]ecipe","Check [I]nventory"]

    print "\n--Day " + str(bizDay) + "--\n"

    for op in options:
        print op

    user_selection = raw_input("\n>>> ").upper() or "S"

    if user_selection == 'S':
        saleLemonade()

    if user_selection == 'B':
        buySupplies()

    if user_selection == 'M':
        makeLemonade()

    if user_selection == 'I':
        checkInventory()

    if user_selection == "STATS":
        print "Total Days: " + str(bizDay)
        print "Total Sales: $" + str(round(float(statTotalSales),2))
        print "Total Cups Sold: " + str(statTotalCups)
        print "Average Earnings per Day: $" + str(round(statTotalSales/float(bizDay),2))
        print "Average Sales per Day: " + str(statTotalCups/bizDay)

    if user_selection == "Q":
        print "What a business! Good job!"
        print "Total Days: " + str(bizDay)
        print "Total Sales: $" + str(round(float(statTotalSales),2))
        print "Total Cups Sold: " + str(statTotalCups)
        print "Average Earnings per Day: " + str(round(statTotalSales/float(bizDay),2))
        print "Average Sales per Day: " + str(statTotalCups/bizDay)
        game_on = False
        
    

##if __name__ == "__main__":
##    makeLemonade()
