import time
import random
import os


global water_units
global lemon_units
global sugar_units
global wallet
global recipe
global bizDay
global batch
global waterPrice
global lemonPrice
global sugarPrice
global marketFlag
global ReportTitle

# game stats
global statTotalSales
global statTotalCups

water_units = 4
lemon_units = 4
sugar_units = 8
wallet = 20.00
recipe = [3,2,1]
bizDay = 1
batch = 20
marketFlag = False
statTotalSales = 0
statTotalCups = 0
os.system("mode con cols=87 lines=40")

# Make Profit stat Net Gain/Net Loss)

ReportTitle = time.strftime("%Y_%H%M%S", time.gmtime())

def create_banner(banner_file="banner.txt",whichMenu="start"):
    options_menu=["[S]tart Game","settin[G]s"]

    if whichMenu == "start":
        with open(banner_file,'rb') as banner:
            print banner.read()
            time.sleep(2)
            for each in options_menu:
                gap = (84-len(each))/2
                print " "*gap + each + " "*gap
        userStart = raw_input(">>> ") or "S"
        return userStart.upper()
                
    if whichMenu == "continue":
        print "SELECT AN OPTION:"
        print "=-" * 12
        for each in options_menu:
            print each
        print "\n"

    if whichMenu == "about":
        with open(banner_file,'rb') as banner:
            print banner.read()

    if whichMenu == "end":
        with open(banner_file,'rb') as banner:
            print banner.read()


def setMarket():
    global waterPrice
    global lemonPrice
    global sugarPrice

    waterPrice = float(random.randint(1,3))
    lemonPrice = float(random.randint(2,5))
    sugarPrice = float(random.randint(4,7))


def checkInventory():
    global water_units
    global lemon_units
    global sugar_units
    global wallet
    global bizDay
    global batch

    print "-"*45
    print "ON HAND LIST (DAY: " + str(bizDay) + ")"
    print "-"*45
    print "Water OH: " + str(water_units)
    print "Lemon OH: " + str(lemon_units)
    print "Sugar OH: " + str(sugar_units)
    print "Ready to Sell: " + str(batch)
    print "Wallet :$" + str(("%.2f" % wallet))
    
def makeLemonade():
    global water_units
    global lemon_units
    global sugar_units
    global recipe
    global batch

    print "\nLet's make Lemonade! 1 Batch = 20 cups"
    userBatch = int(raw_input("How many batches do you want to make?: ") or 1)
    waterNeeded = 3*userBatch
    lemonNeeded = 2*userBatch
    sugarNeeded = 1*userBatch

    if water_units >= waterNeeded and\
       lemon_units >= lemonNeeded and sugar_units >= sugarNeeded:

        water_units -= waterNeeded
        lemon_units -= lemonNeeded
        sugar_units -= sugarNeeded

        batch += (userBatch * 20)
    
    else:
        if water_units < waterNeeded:
            print "\nNot enough water" + " for " + str(userBatch) + " batches.\nNEED: " + str(waterNeeded) 
            print "HAVE: " + str(water_units)
            
        elif lemon_units < lemonNeeded:
            print "\nNot enough lemon" + " for " + str(userBatch) + " batches.\nNEED: " + str(lemonNeeded)
            print "HAVE: " + str(lemon_units)

        elif sugar_units < sugarNeeded:
            print "\nNot enough sugar" + " for " + str(userBatch) + " batches.\nNEED: " + str(userBatch)
            print "HAVE: " + str(sugar_units)

    print "\nYou have " + str(batch) + " ready to sell!\n"

    
def saleLemonade():
    global wallet
    global bizDay
    global batch
    global marketFlag

    global statTotalSales
    global statTotalCups

    whammyFlag = random.randint(0,20)
    
    start = 0
    sold_out_flag = 0

    sold_qty = 0
    
    try:
        sellPrice = float(raw_input("What price do you want to set?: $") or 2.25)
    except:
        sellPrice = 1.00
        
    priceRange = [0.25,0.35,0.45]
    priceGauge = priceRange[random.randint(0,2)]
    till = 0

    #print priceGauge
    
    if batch >0:

        create_banner("sale_banner.txt","about")
        buy_chance = 0
        
        while start <= 60:
            willingPrice = round(random.uniform(0.75,2.5),2)
            interestFlag = random.randint(0,1)
            
            if abs(sellPrice - willingPrice ) <= priceGauge\
               and interestFlag == 1:
                buy_chance = 1

            if buy_chance == 1 and batch > 0:

                wantedQty = random.randint(1,3)
                if wantedQty > batch:
                    wantedQty = batch

                #print wantedQty
                    
                batch -= wantedQty
                sold_qty += wantedQty
            else:
                if batch == 0:
                    sold_out_flag += 1

            if sold_out_flag == 1:
                print " " * 31 + 'SOLD OUT @ ' + str(start%12) +'Hrs'
                sold_out_flag += 1

            #time.sleep(1)
            start += 1
            
        till = float(sold_qty * sellPrice)
        print " " * 31 + "You made: $" + str(("%.2f" % till))
        wallet += till
        statTotalSales += till
        statTotalCups += sold_qty
        collectData(bizDay,sellPrice,priceGauge,till,sold_qty,wallet)
        bizDay += 1
        
    else:
        print "\nYou don't have enough supplies to open"

    marketFlag = False
    
    if whammyFlag == 2 and batch <> 0:
        print " " * 15 + "OH NO! The batch went bad! You Lost ("+ str(batch) + ") R2S units.\n"
        batch = 0
    if whammyFlag == 6 and wallet >= 100.00:
        fine = random.randint(75,100)
        print " " * 10 + "UH OH! Health Department found violations! Pay the Piper $"+ str(fine) + "!\n"
        wallet -= fine
    if whammyFlag == 13 and wallet > 15.00:
        stolenAmt = random.randint(5,15)
        print " " * 10 + "DOH! Hire better staff; the new worker stole $"+ str(stolenAmt) + " from the till!\n"
        wallet -= stolenAmt
        
    
        
def collectData(day,dailyPrice,dailyGuage,dailyTill,dailySold,dailyFunds):
    with open(os.path.dirname(__file__)+"/reports/"+ReportTitle+'_dailyReport.csv','a+') as dailyReport:
        if bizDay == 1:
            dailyReport.write("day,dailyPrice,dailyGauge,dailyTill,dailySold,dailyFunds\n")
            
        dailyReport.write(str(day)+","+str(("%.2f" % dailyPrice))+","+str(("%.2f" % dailyGuage))+"," +\
                          str(("%.2f" % dailyTill))+","+str(dailySold)+","+str(("%.2f" % dailyFunds))+"\n")

def buySupplies(): 
    global water_units
    global lemon_units
    global sugar_units
    global waterPrice
    global lemonPrice
    global sugarPrice
    global wallet
    global marketFlag

    if marketFlag == False:
        setMarket()

    options = ["[W]ater ($"+str(waterPrice)+")","[L]emons ($"+str(lemonPrice)+")",\
               "s[U]gar ($"+str(sugarPrice)+")","\n[C]heck Wallet"]

    for op in options:
        print op

    grandTotal = 0.00

    inStore_flag = True
    while inStore_flag == True:
        purchaseTotal = 0.00

        try:
            userShelf = raw_input("\nWhat do you want to buy?: ").upper() or "X"
        except:
            userShelf = "X"

        if userShelf =="W":
            try:
                userQty = int(raw_input("Desire quanity: ") or 1.00)
            except:
                userQty = 1.00

            purchaseTotal += (float(userQty)*waterPrice)
            grandTotal += purchaseTotal
            
            if wallet < purchaseTotal:
                print "\nYou don't have enough to buy "\
                      + str(int(userQty)) + " units of water."
            else:
                wallet -= purchaseTotal
                water_units += int(userQty)
                
                
        if userShelf =="L":
            try:
                userQty = int(raw_input("Desire quanity: ") or 1.00)
            except:
                userQty = 1.00

            purchaseTotal += (float(userQty)*lemonPrice)
            grandTotal += purchaseTotal
            if wallet < purchaseTotal:
                print "\nYou don't have enough to buy "\
                      + str(int(userQty)) + " units of lemons."
            else:
                wallet -= purchaseTotal
                lemon_units += int(userQty)

        if userShelf =="U":
            try:
                userQty = int(raw_input("Desire quanity: ") or 1.00)
            except:
                userQty = 1.00

            purchaseTotal += (float(userQty)*sugarPrice)
            grandTotal += purchaseTotal
            if wallet < purchaseTotal:
                print "\nYou don't have enough to buy "\
                      + str(int(userQty)) + " units of sugar."
                
            else:
                wallet -= purchaseTotal
                sugar_units += int(userQty)
                
        if userShelf =="C":
            print "You have $" + str(("%.2f" % wallet)) + "."

        if userShelf =="X":
            userConfirmation = raw_input("Are your sure?: ").upper() or "Y"
            if userConfirmation == "Y":
                inStore_flag = False
            else:
                inStore_flag = True
                
    
    print "\nThank you for shopping\nYou spent $" + ("%.2f" % grandTotal)
    print "Wallet :$" + str(("%.2f" % wallet))
    marketFlag = True

def showStats():
    global bizDay
    global statTotalSales
    global statTotalCups
    
    print "Total Days: " + str(bizDay)
    print "Total Sales: $" + str(round(float(statTotalSales),2))
    print "Total Cups Sold: " + str(statTotalCups)
    print "Average Earnings per Day: $" + str(round(statTotalSales/float(bizDay),2))
    print "Average Sales per Day: " + str(statTotalCups/bizDay)


    

if __name__ == "__main__":
    if create_banner() == 'S':
        game_on = True
        gameLength = 60
        
        while game_on == True:
            if bizDay == gameLength+1:
                print "What a business! Good job!"
                showStats()
                break
                
            options = ["[S]ale Lemonade","[B]uy Supplies",\
                       "[M]ake Lemondade","[R]ecipe","Check [I]nventory","[A]bout"]

            print "\n--Day " + str(bizDay) + "--\n"

            for op in options:
                print op

            user_selection = raw_input("\n>>> ").upper() or "S"

            if user_selection == 'S':
                saleLemonade()

            if user_selection == 'B':
                buySupplies()

            if user_selection == 'M':
                makeLemonade()

            if user_selection == 'I':
                checkInventory()

            if user_selection == 'A':
                create_banner("about_banner.txt","about")

            if user_selection == "STATS":
                showStats()

            if user_selection == "Q":
                print "What a business! Good job!"
                showStats()
                game_on = False
            
